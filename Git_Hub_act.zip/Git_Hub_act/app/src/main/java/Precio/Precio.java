package Precio;

public class Precio {
    private int fareneith;
    private int revival;
    private int el_aquimista;

    public Precio(){
        fareneith=7000;
        revival=22000;
        el_aquimista=45000;
    }

    public int getFareneith(){
        return fareneith;
    }
    public int getRevival(){
        return revival;
    }
    public int getEl_aquimista(){
        return el_aquimista;
    }
}
